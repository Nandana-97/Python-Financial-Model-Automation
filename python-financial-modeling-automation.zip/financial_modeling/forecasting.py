from __future__ import annotations

from financial_modeling.models import Assumptions

ProjectionRow = dict[str, float | int]


def project_cash_flows(assumptions: Assumptions) -> list[ProjectionRow]:
    """Project operating metrics and unlevered free cash flow."""

    rows: list[ProjectionRow] = []
    prior_revenue = assumptions.base_revenue

    for year in range(1, assumptions.projection_years + 1):
        revenue = prior_revenue * (1 + assumptions.revenue_growth)
        ebitda = revenue * assumptions.ebitda_margin
        depreciation = revenue * assumptions.depreciation_pct_revenue
        ebit = ebitda - depreciation
        taxes = max(ebit, 0) * assumptions.tax_rate
        nopat = ebit - taxes
        capex = revenue * assumptions.capex_pct_revenue
        change_nwc = (revenue - prior_revenue) * assumptions.nwc_pct_revenue
        free_cash_flow = nopat + depreciation - capex - change_nwc

        rows.append(
            {
                "year": year,
                "revenue": revenue,
                "ebitda": ebitda,
                "depreciation": depreciation,
                "ebit": ebit,
                "taxes": taxes,
                "nopat": nopat,
                "capex": capex,
                "change_nwc": change_nwc,
                "free_cash_flow": free_cash_flow,
            }
        )
        prior_revenue = revenue

    return rows
