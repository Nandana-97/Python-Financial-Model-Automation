from __future__ import annotations

from html import escape
from pathlib import Path


def write_chart_svg(
    path: str | Path,
    projections: list[dict[str, float | int]],
    scenarios: list[dict[str, float | str]],
    metrics: list[dict[str, float | str]],
) -> None:
    """Write a dependency-free SVG dashboard with forecast, scenario, and metric views."""

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    svg = [
        '<svg xmlns="http://www.w3.org/2000/svg" width="1120" height="780" viewBox="0 0 1120 780">',
        '<rect width="1120" height="780" fill="#f7f8fb"/>',
        _title("Financial Model Dashboard", 48, 50, 30),
        _subtitle("Revenue, free cash flow, scenario valuation, and performance metrics", 48, 78),
        _line_chart(projections, 48, 120, 510, 270),
        _scenario_bars(scenarios, 610, 120, 460, 270),
        _metrics_panel(metrics, 48, 450, 1022, 250),
        "</svg>",
    ]
    path.write_text("\n".join(svg), encoding="utf-8")


def _line_chart(
    projections: list[dict[str, float | int]], x: int, y: int, width: int, height: int
) -> str:
    revenue = [float(row["revenue"]) for row in projections]
    fcf = [float(row["free_cash_flow"]) for row in projections]
    max_value = max([*revenue, *fcf])
    rev_points = _points(revenue, x, y, width, height, max_value)
    fcf_points = _points(fcf, x, y, width, height, max_value)

    labels = []
    for index, row in enumerate(projections):
        px = x + index * (width / (len(projections) - 1))
        labels.append(_text(str(row["year"]), px - 4, y + height + 24, 13, "#53606f"))

    return "\n".join(
        [
            _panel(x, y, width, height + 52),
            _title("Cash Flow Forecast", x + 22, y + 34, 22),
            _axis(x + 28, y + 58, width - 56, height - 58),
            f'<polyline points="{rev_points}" fill="none" stroke="#20639b" stroke-width="4"/>',
            f'<polyline points="{fcf_points}" fill="none" stroke="#3caea3" stroke-width="4"/>',
            *labels,
            _legend(x + 28, y + height + 42, "#20639b", "Revenue"),
            _legend(x + 140, y + height + 42, "#3caea3", "Free cash flow"),
        ]
    )


def _scenario_bars(
    scenarios: list[dict[str, float | str]], x: int, y: int, width: int, height: int
) -> str:
    prices = [float(row["implied_share_price"]) for row in scenarios]
    max_price = max(prices)
    bar_width = 78
    gap = (width - 72 - bar_width * len(scenarios)) / (len(scenarios) - 1)
    bars = []

    for index, row in enumerate(scenarios):
        price = float(row["implied_share_price"])
        bar_height = (price / max_price) * (height - 108)
        bx = x + 36 + index * (bar_width + gap)
        by = y + height - 44 - bar_height
        label = escape(str(row["scenario"]))
        bars.extend(
            [
                f'<rect x="{bx:.1f}" y="{by:.1f}" width="{bar_width}" height="{bar_height:.1f}" rx="6" fill="#f6a13a"/>',
                _text(f"${price:,.2f}", bx - 4, by - 10, 14, "#293241"),
                _text(label, bx + 8, y + height - 18, 14, "#53606f"),
            ]
        )

    return "\n".join(
        [
            _panel(x, y, width, height + 52),
            _title("Scenario Share Price", x + 22, y + 34, 22),
            *bars,
        ]
    )


def _metrics_panel(
    metrics: list[dict[str, float | str]], x: int, y: int, width: int, height: int
) -> str:
    metric_rows = []
    visible_metrics = metrics[:6]
    columns = 3
    cell_width = (width - 56) / columns

    for index, row in enumerate(visible_metrics):
        col = index % columns
        line = index // columns
        mx = x + 28 + col * cell_width
        my = y + 74 + line * 82
        value = float(row["value"])
        formatted = _format_metric(str(row["metric"]), value)
        metric_rows.extend(
            [
                _text(escape(str(row["metric"])), mx, my, 15, "#53606f"),
                _text(formatted, mx, my + 32, 28, "#293241"),
            ]
        )

    return "\n".join(
        [
            _panel(x, y, width, height),
            _title("Performance Metrics", x + 22, y + 38, 22),
            *metric_rows,
        ]
    )


def _points(values: list[float], x: int, y: int, width: int, height: int, max_value: float) -> str:
    chart_top = y + 62
    chart_height = height - 76
    return " ".join(
        f"{x + 28 + index * ((width - 56) / (len(values) - 1)):.1f},"
        f"{chart_top + chart_height - (value / max_value) * chart_height:.1f}"
        for index, value in enumerate(values)
    )


def _format_metric(metric: str, value: float) -> str:
    if "Margin" in metric or "CAGR" in metric or "Conversion" in metric:
        return f"{value:.1%}"
    if metric.startswith("EV /"):
        return f"{value:.1f}x"
    return f"${value:,.0f}"


def _panel(x: int, y: int, width: int, height: int) -> str:
    return f'<rect x="{x}" y="{y}" width="{width}" height="{height}" rx="8" fill="#ffffff" stroke="#d9dee8"/>'


def _axis(x: int, y: int, width: int, height: int) -> str:
    return "\n".join(
        [
            f'<line x1="{x}" y1="{y + height}" x2="{x + width}" y2="{y + height}" stroke="#bcc6d4"/>',
            f'<line x1="{x}" y1="{y}" x2="{x}" y2="{y + height}" stroke="#bcc6d4"/>',
        ]
    )


def _title(text: str, x: float, y: float, size: int) -> str:
    return _text(text, x, y, size, "#293241", weight=700)


def _subtitle(text: str, x: float, y: float) -> str:
    return _text(text, x, y, 16, "#53606f")


def _legend(x: float, y: float, color: str, label: str) -> str:
    return (
        f'<rect x="{x}" y="{y - 12}" width="16" height="4" fill="{color}"/>'
        f'{_text(label, x + 24, y - 6, 13, "#53606f")}'
    )


def _text(text: str, x: float, y: float, size: int, color: str, weight: int = 400) -> str:
    return (
        f'<text x="{x}" y="{y}" fill="{color}" font-family="Arial, sans-serif" '
        f'font-size="{size}" font-weight="{weight}">{text}</text>'
    )
