from __future__ import annotations

import argparse
import csv
from pathlib import Path

from financial_modeling.charts import write_chart_svg
from financial_modeling.dcf import value_company
from financial_modeling.forecasting import project_cash_flows
from financial_modeling.io import load_assumptions, override_assumptions
from financial_modeling.metrics import performance_metrics
from financial_modeling.scenarios import run_scenarios, sensitivity_table


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run automated DCF valuation and scenario analysis."
    )
    parser.add_argument(
        "--assumptions",
        type=Path,
        default=Path("data/assumptions.csv"),
        help="Path to assumptions CSV.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("outputs/valuation_report.csv"),
        help="Path for combined CSV report.",
    )
    parser.add_argument(
        "--chart-output",
        type=Path,
        default=Path("outputs/valuation_dashboard.svg"),
        help="Path for SVG dashboard output.",
    )
    parser.add_argument(
        "--set",
        action="append",
        dest="overrides",
        help="Override an assumption with field=value. May be used multiple times.",
    )
    args = parser.parse_args()

    assumptions = override_assumptions(load_assumptions(args.assumptions), args.overrides)
    valuation = value_company(assumptions)
    projections = project_cash_flows(assumptions)
    scenarios = run_scenarios(assumptions)
    sensitivity = sensitivity_table(assumptions)
    metrics = performance_metrics(assumptions, projections, valuation)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    _write_report(args.output, projections, scenarios, sensitivity, metrics)
    write_chart_svg(args.chart_output, projections, scenarios, metrics)

    print(f"{assumptions.company_name} DCF valuation")
    print(f"Enterprise value: ${valuation.enterprise_value:,.2f}")
    print(f"Equity value:     ${valuation.equity_value:,.2f}")
    print(f"Share price:      ${valuation.implied_share_price:,.2f}")
    print(f"Report written:   {args.output}")
    print(f"Chart written:    {args.chart_output}")


def _write_report(
    path: Path,
    projections: list[dict[str, float | int]],
    scenarios: list[dict[str, float | str]],
    sensitivity: list[dict[str, float | str]],
    metrics: list[dict[str, float | str]],
) -> None:
    rows = [
        *_section("Projected Cash Flows", projections),
        *_section("Scenario Valuation", scenarios),
        *_section("Sensitivity Analysis", sensitivity),
        *_section("Performance Metrics", metrics),
    ]
    fieldnames = ["section", *sorted({key for row in rows for key in row if key != "section"})]

    with path.open("w", newline="") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def _section(
    name: str, rows: list[dict[str, float | int | str]]
) -> list[dict[str, float | int | str]]:
    return [{"section": name, **row} for row in rows]


if __name__ == "__main__":
    main()
