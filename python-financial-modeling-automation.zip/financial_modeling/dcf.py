from __future__ import annotations

from financial_modeling.forecasting import project_cash_flows
from financial_modeling.models import Assumptions, ValuationResult


def value_company(assumptions: Assumptions, scenario: str = "Base") -> ValuationResult:
    """Run a DCF valuation from projected cash flows."""

    if assumptions.wacc <= assumptions.terminal_growth:
        raise ValueError("WACC must be greater than terminal growth")
    if assumptions.shares_outstanding <= 0:
        raise ValueError("Shares outstanding must be greater than zero")

    projections = project_cash_flows(assumptions)
    projected_fcf = [float(row["free_cash_flow"]) for row in projections]
    pv_fcf = _present_value_series(projected_fcf, assumptions.wacc)

    final_fcf = projected_fcf[-1]
    terminal_value = final_fcf * (1 + assumptions.terminal_growth) / (
        assumptions.wacc - assumptions.terminal_growth
    )
    pv_terminal = terminal_value / (1 + assumptions.wacc) ** assumptions.projection_years
    enterprise_value = pv_fcf + pv_terminal
    equity_value = enterprise_value + assumptions.cash - assumptions.debt
    implied_share_price = equity_value / assumptions.shares_outstanding

    return ValuationResult(
        scenario=scenario,
        enterprise_value=enterprise_value,
        equity_value=equity_value,
        implied_share_price=implied_share_price,
        terminal_value=terminal_value,
        present_value_fcf=pv_fcf,
        present_value_terminal=pv_terminal,
    )


def _present_value_series(values: list[float], discount_rate: float) -> float:
    return float(
        sum(value / (1 + discount_rate) ** period for period, value in enumerate(values, 1))
    )
