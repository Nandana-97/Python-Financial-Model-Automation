from __future__ import annotations

from financial_modeling.models import Assumptions, ValuationResult


def performance_metrics(
    assumptions: Assumptions,
    projections: list[dict[str, float | int]],
    valuation: ValuationResult,
) -> list[dict[str, float | str]]:
    """Calculate performance and valuation metrics from projections."""

    first_revenue = float(projections[0]["revenue"])
    final_revenue = float(projections[-1]["revenue"])
    final_ebitda = float(projections[-1]["ebitda"])
    final_fcf = float(projections[-1]["free_cash_flow"])
    average_fcf_margin = sum(
        float(row["free_cash_flow"]) / float(row["revenue"]) for row in projections
    ) / len(projections)
    average_ebitda_margin = sum(
        float(row["ebitda"]) / float(row["revenue"]) for row in projections
    ) / len(projections)
    revenue_cagr = (final_revenue / assumptions.base_revenue) ** (
        1 / assumptions.projection_years
    ) - 1

    return [
        {"metric": "Revenue CAGR", "value": revenue_cagr},
        {"metric": "Average EBITDA Margin", "value": average_ebitda_margin},
        {"metric": "Average FCF Margin", "value": average_fcf_margin},
        {"metric": "Final Year FCF Conversion", "value": final_fcf / final_ebitda},
        {"metric": "EV / Final Revenue", "value": valuation.enterprise_value / final_revenue},
        {"metric": "EV / Final EBITDA", "value": valuation.enterprise_value / final_ebitda},
        {"metric": "Net Debt", "value": assumptions.debt - assumptions.cash},
    ]
