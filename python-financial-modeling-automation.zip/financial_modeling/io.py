from __future__ import annotations

import csv
from pathlib import Path
from typing import Any

from financial_modeling.models import Assumptions


REQUIRED_FIELDS = {
    "company_name",
    "base_revenue",
    "revenue_growth",
    "ebitda_margin",
    "depreciation_pct_revenue",
    "capex_pct_revenue",
    "nwc_pct_revenue",
    "tax_rate",
    "wacc",
    "terminal_growth",
    "cash",
    "debt",
    "shares_outstanding",
    "projection_years",
}


def load_assumptions(path: str | Path) -> Assumptions:
    """Load model assumptions from a two-column CSV file."""

    with Path(path).open(newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        if reader.fieldnames != ["field", "value"]:
            raise ValueError("Assumptions CSV must contain exactly: field,value")
        raw = {row["field"]: row["value"] for row in reader}

    missing = REQUIRED_FIELDS - set(raw)
    if missing:
        missing_fields = ", ".join(sorted(missing))
        raise ValueError(f"Missing required assumptions: {missing_fields}")

    assumptions = Assumptions(
        company_name=str(raw["company_name"]),
        base_revenue=_as_float(raw, "base_revenue"),
        revenue_growth=_as_float(raw, "revenue_growth"),
        ebitda_margin=_as_float(raw, "ebitda_margin"),
        depreciation_pct_revenue=_as_float(raw, "depreciation_pct_revenue"),
        capex_pct_revenue=_as_float(raw, "capex_pct_revenue"),
        nwc_pct_revenue=_as_float(raw, "nwc_pct_revenue"),
        tax_rate=_as_float(raw, "tax_rate"),
        wacc=_as_float(raw, "wacc"),
        terminal_growth=_as_float(raw, "terminal_growth"),
        cash=_as_float(raw, "cash"),
        debt=_as_float(raw, "debt"),
        shares_outstanding=_as_float(raw, "shares_outstanding"),
        projection_years=int(_as_float(raw, "projection_years")),
    )
    validate_assumptions(assumptions)
    return assumptions


def override_assumptions(
    assumptions: Assumptions, overrides: list[str] | None
) -> Assumptions:
    """Apply CLI overrides formatted as field=value."""

    if not overrides:
        return assumptions

    values: dict[str, float | str | int] = {}
    for override in overrides:
        if "=" not in override:
            raise ValueError(f"Override {override!r} must use field=value format")
        field, value = override.split("=", 1)
        if field not in REQUIRED_FIELDS:
            raise ValueError(f"Unknown assumption field: {field}")
        values[field] = value if field == "company_name" else float(value)

    if "projection_years" in values:
        values["projection_years"] = int(values["projection_years"])

    updated = assumptions.with_changes(**values)
    validate_assumptions(updated)
    return updated


def validate_assumptions(assumptions: Assumptions) -> None:
    """Validate ranges so bad assumptions fail before valuation."""

    if not assumptions.company_name.strip():
        raise ValueError("company_name cannot be blank")
    if assumptions.base_revenue <= 0:
        raise ValueError("base_revenue must be greater than zero")
    if assumptions.shares_outstanding <= 0:
        raise ValueError("shares_outstanding must be greater than zero")
    if assumptions.projection_years < 1:
        raise ValueError("projection_years must be at least 1")
    if assumptions.debt < 0 or assumptions.cash < 0:
        raise ValueError("cash and debt cannot be negative")

    bounded_rates = {
        "ebitda_margin": assumptions.ebitda_margin,
        "depreciation_pct_revenue": assumptions.depreciation_pct_revenue,
        "capex_pct_revenue": assumptions.capex_pct_revenue,
        "nwc_pct_revenue": assumptions.nwc_pct_revenue,
        "tax_rate": assumptions.tax_rate,
    }
    for field, value in bounded_rates.items():
        if not 0 <= value <= 1:
            raise ValueError(f"{field} must be between 0 and 1")

    if assumptions.wacc <= assumptions.terminal_growth:
        raise ValueError("wacc must be greater than terminal_growth")


def _as_float(raw: dict[str, Any], field: str) -> float:
    try:
        return float(raw[field])
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Assumption {field!r} must be numeric") from exc
