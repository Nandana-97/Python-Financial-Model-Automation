from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Assumptions:
    """Operating and valuation assumptions used by the model."""

    company_name: str
    base_revenue: float
    revenue_growth: float
    ebitda_margin: float
    depreciation_pct_revenue: float
    capex_pct_revenue: float
    nwc_pct_revenue: float
    tax_rate: float
    wacc: float
    terminal_growth: float
    cash: float
    debt: float
    shares_outstanding: float
    projection_years: int = 5

    def with_changes(self, **changes: float | str | int) -> "Assumptions":
        values = self.__dict__ | changes
        return Assumptions(**values)


@dataclass(frozen=True)
class ValuationResult:
    scenario: str
    enterprise_value: float
    equity_value: float
    implied_share_price: float
    terminal_value: float
    present_value_fcf: float
    present_value_terminal: float
