from __future__ import annotations

from financial_modeling.dcf import value_company
from financial_modeling.models import Assumptions


SCENARIO_ADJUSTMENTS = {
    "Downside": {"revenue_growth": -0.03, "ebitda_margin": -0.02, "wacc": 0.01},
    "Base": {"revenue_growth": 0.0, "ebitda_margin": 0.0, "wacc": 0.0},
    "Upside": {"revenue_growth": 0.03, "ebitda_margin": 0.02, "wacc": -0.005},
}


def run_scenarios(assumptions: Assumptions) -> list[dict[str, float | str]]:
    """Run downside, base, and upside DCF cases."""

    results = []
    for scenario, adjustments in SCENARIO_ADJUSTMENTS.items():
        case = assumptions.with_changes(
            revenue_growth=assumptions.revenue_growth + adjustments["revenue_growth"],
            ebitda_margin=assumptions.ebitda_margin + adjustments["ebitda_margin"],
            wacc=assumptions.wacc + adjustments["wacc"],
        )
        results.append(value_company(case, scenario=scenario).__dict__)

    return results


def sensitivity_table(
    assumptions: Assumptions,
    wacc_range: list[float] | None = None,
    terminal_growth_range: list[float] | None = None,
) -> list[dict[str, float | str]]:
    """Create an implied share price table by WACC and terminal growth."""

    wacc_range = wacc_range or [
        assumptions.wacc - 0.01,
        assumptions.wacc - 0.005,
        assumptions.wacc,
        assumptions.wacc + 0.005,
        assumptions.wacc + 0.01,
    ]
    terminal_growth_range = terminal_growth_range or [
        assumptions.terminal_growth - 0.005,
        assumptions.terminal_growth,
        assumptions.terminal_growth + 0.005,
    ]

    rows = []
    for terminal_growth in terminal_growth_range:
        row: dict[str, float | str] = {"terminal_growth": terminal_growth}
        for wacc in wacc_range:
            case = assumptions.with_changes(wacc=wacc, terminal_growth=terminal_growth)
            row[f"wacc_{wacc:.1%}"] = value_company(case).implied_share_price
        rows.append(row)

    return rows
