import tempfile
import unittest
from pathlib import Path

from financial_modeling.charts import write_chart_svg
from financial_modeling.dcf import value_company
from financial_modeling.forecasting import project_cash_flows
from financial_modeling.io import load_assumptions, override_assumptions
from financial_modeling.metrics import performance_metrics
from financial_modeling.scenarios import run_scenarios, sensitivity_table


class FinancialModelingTests(unittest.TestCase):
    def setUp(self):
        self.assumptions = load_assumptions("data/assumptions.csv")

    def test_project_cash_flows_has_expected_years(self):
        projections = project_cash_flows(self.assumptions)

        self.assertEqual(len(projections), self.assumptions.projection_years)
        self.assertGreater(projections[0]["free_cash_flow"], 0)
        revenues = [row["revenue"] for row in projections]
        self.assertEqual(revenues, sorted(revenues))

    def test_dcf_returns_positive_equity_value(self):
        result = value_company(self.assumptions)

        self.assertGreater(result.enterprise_value, 0)
        self.assertGreater(result.equity_value, 0)
        self.assertAlmostEqual(
            result.implied_share_price,
            result.equity_value / self.assumptions.shares_outstanding,
        )

    def test_scenarios_order_share_price_by_case(self):
        scenarios = {
            row["scenario"]: row for row in run_scenarios(self.assumptions)
        }

        self.assertGreater(
            scenarios["Upside"]["implied_share_price"],
            scenarios["Base"]["implied_share_price"],
        )
        self.assertGreater(
            scenarios["Base"]["implied_share_price"],
            scenarios["Downside"]["implied_share_price"],
        )

    def test_sensitivity_table_shape(self):
        table = sensitivity_table(self.assumptions)

        self.assertEqual(len(table), 3)
        self.assertEqual(len(table[0]), 6)
        self.assertIn("terminal_growth", table[0])

    def test_assumption_overrides_are_validated_and_applied(self):
        updated = override_assumptions(
            self.assumptions, ["revenue_growth=0.12", "projection_years=3"]
        )

        self.assertEqual(updated.revenue_growth, 0.12)
        self.assertEqual(updated.projection_years, 3)
        self.assertEqual(len(project_cash_flows(updated)), 3)

    def test_invalid_inputs_fail_fast(self):
        with self.assertRaises(ValueError):
            override_assumptions(self.assumptions, ["shares_outstanding=0"])

        with self.assertRaises(ValueError):
            override_assumptions(self.assumptions, ["unknown=1"])

    def test_performance_metrics_include_core_outputs(self):
        projections = project_cash_flows(self.assumptions)
        valuation = value_company(self.assumptions)

        metrics = performance_metrics(self.assumptions, projections, valuation)
        metric_names = {row["metric"] for row in metrics}

        self.assertIn("Revenue CAGR", metric_names)
        self.assertIn("EV / Final EBITDA", metric_names)

    def test_chart_svg_is_created(self):
        projections = project_cash_flows(self.assumptions)
        scenarios = run_scenarios(self.assumptions)
        valuation = value_company(self.assumptions)
        metrics = performance_metrics(self.assumptions, projections, valuation)

        with tempfile.TemporaryDirectory() as tmpdir:
            output = Path(tmpdir) / "dashboard.svg"
            write_chart_svg(output, projections, scenarios, metrics)

            self.assertTrue(output.exists())
            self.assertIn("<svg", output.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
