# Python-Based Financial Modeling & Automation

Automated financial modeling toolkit for valuation, forecasting, DCF analysis,
scenario simulation, and sensitivity analysis.

The project translates standard corporate finance theory into reusable Python
models that reduce manual spreadsheet work and make assumptions easy to audit.

## Features

- Five-year cash flow projection engine
- Discounted cash flow valuation with terminal value
- Base, downside, and upside scenario simulation
- WACC and terminal growth sensitivity table
- Performance metrics such as revenue CAGR, FCF margin, EV/revenue, and EV/EBITDA
- Dependency-free SVG dashboard with forecast, scenario, and metrics graphs
- CSV input/output workflow for repeatable analysis
- CLI overrides for assumptions without editing the CSV
- CLI entry point for running a full valuation report
- Unit tests for valuation math and scenario behavior

## Project Structure

```text
financial_modeling/
  cli.py              # Command-line workflow
  dcf.py              # DCF valuation formulas
  forecasting.py      # Financial statement projections
  io.py               # CSV assumptions loader
  models.py           # Dataclasses for assumptions/results
  scenarios.py        # Scenario and sensitivity analysis
data/
  assumptions.csv     # Example operating and valuation assumptions
outputs/
  .gitkeep            # Generated reports are written here
tests/
  test_financial_modeling.py
```

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
python -m financial_modeling.cli --assumptions data/assumptions.csv --output outputs/valuation_report.csv --chart-output outputs/valuation_dashboard.svg
```

Override any assumption from the command line:

```bash
python -m financial_modeling.cli --set revenue_growth=0.12 --set wacc=0.095
```

Run tests:

```bash
python -m unittest discover
```

## Example Output

The CLI prints an equity valuation summary and writes a CSV report with:

- Scenario-level DCF valuation
- Projected revenue, EBITDA, taxes, reinvestment, and free cash flow
- Sensitivity matrix across WACC and terminal growth assumptions
- Performance metric summary
- SVG dashboard chart saved to `outputs/valuation_dashboard.svg`

## Core Financial Logic

Free cash flow is calculated as:

```text
FCF = EBIT x (1 - tax rate) + D&A - capital expenditures - change in net working capital
```

Enterprise value is calculated as:

```text
EV = PV(projected FCF) + PV(terminal value)
Terminal Value = final year FCF x (1 + terminal growth) / (WACC - terminal growth)
Equity Value = EV + cash - debt
```

## Portfolio Summary

This project demonstrates the ability to:

- Build automated financial models using Python
- Implement DCF frameworks, cash flow projections, and sensitivity analysis
- Improve efficiency and scalability by replacing manual computations
- Translate finance theory into testable computational models
